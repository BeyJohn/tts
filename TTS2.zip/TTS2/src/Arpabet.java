import java.io.File;
import java.io.SequenceInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.TreeMap;

import javax.sound.sampled.AudioFileFormat.Type;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Arpabet
{
	private static TreeMap<String, ArrayList<String>> converter = new TreeMap<>();
	
	public Arpabet() throws Exception
	{
		try (Scanner read = new Scanner(new File("cmudict-0.7b.txt")))
		{
			while (read.hasNextLine())
			{
				String line = read.nextLine();
				if (!line.startsWith(";;;"))
				{
					String[] temp = line.split("\\s\\s", 2);
					String word = temp[0];
					ArrayList<String> toAdd = new ArrayList<>();
					temp = temp[1].split("\\s");
					for (String s : temp)
					{
						toAdd.add(s);
					}
					converter.put(word, toAdd);
				}
			}
		}
	}
	
	public void textToSpeach(String sentence) throws Exception
	{
		String arpa[] = textToArpa(sentence).split("\\s");
		ArrayList<String> toUse = new ArrayList<>();
		toUse.add("SPACE.wav");
		
		for (String h : arpa)
		{
			String sounds[] = h.split("-");
			for (String s : sounds)
			{
				toUse.add(s.replaceAll("\\p{Punct}", "").concat(".wav")); //
			}
			toUse.add("SPACE.wav");
		}
		
		arpaToSpeach(toUse);
	}
	
	private void arpaToSpeach(ArrayList<String> arpa) throws Exception
	{
		if (arpa.get(1).equals("Please.wav"))
		{
			return;
		}
		try
		{
			AudioFormat format = null;
			ArrayList<AudioInputStream> temp = new ArrayList<>();
			long length = 0;
			for (String s : arpa)
			{
				AudioInputStream t = AudioSystem.getAudioInputStream(new File(s));
				if (format == null)
				{
					format = t.getFormat();
				}
				length += t.getFrameLength();
				temp.add(t);
			}
			AudioSystem.write(
					new AudioInputStream(new SequenceInputStream(Collections.enumeration(temp)), format, length),
					Type.WAVE, new File("temp.wav"));
		}
		finally
		{
			MyLineListener ll = new MyLineListener();
			Thread t = new Thread()
			{
				@Override
				public void run()
				{
					try
					{
						Clip clip = AudioSystem.getClip();
						clip.open(AudioSystem.getAudioInputStream(new File("temp.wav")));
						clip.addLineListener(ll);
						clip.start();
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
			};
			t.start();
			while (ll.isPlaying())
			{
				Thread.sleep(250);
			}
		}
	}
	
	public String textToArpa(String sentence)
	{
		String[] words = sentence.toUpperCase().split("\\s");
		String result = "";
		String uw = null;
		
		for (String w : words)
		{
			if (w == null || w.length() == 0)
			{
				continue;
			}
			if (converter.containsKey(w))
			{
				try
				{
					for (String s : converter.get(w))
					{
						result = result.concat(s).concat("-");
					}
					result = result.substring(0, result.length() - 1).concat(" ");
				}
				catch (Exception e)
				{
					uw = w;
					e.printStackTrace();
				}
			}
			else if (converter.containsKey(w.substring(0, w.length() - 1)))
			{
				try
				{
					for (String s : converter.get(w.substring(0, w.length() - 1)))
					{
						result = result.concat(s).concat("-");
					}
					result = result.substring(0, result.length() - 1).concat(" ");
				}
				catch (Exception e)
				{
					uw = w;
					e.printStackTrace();
				}
			}
			else if (converter.containsKey(w.substring(1)))
			{
				try
				{
					for (String s : converter.get(w.substring(1)))
					{
						result = result.concat(s).concat("-");
					}
					result = result.substring(0, result.length() - 1).concat(" ");
				}
				catch (Exception e)
				{
					uw = w;
					e.printStackTrace();
				}
			}
			else
			{
				uw = w;
				return "Please use correctly spelled words." + "\nUnrecognized word: " + uw;
			}
		}
		
		return result;
	}
}
