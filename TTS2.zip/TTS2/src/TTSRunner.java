import java.util.Scanner;

public class TTSRunner
{

	public static void main(String[] args) throws Exception
	{
		try (Scanner read = new Scanner(System.in))
		{
			Arpabet converter = new Arpabet();
			String temp = read.nextLine();
			System.out.println(converter.textToArpa(temp));
			converter.textToSpeach(temp);
		}
	}

}
