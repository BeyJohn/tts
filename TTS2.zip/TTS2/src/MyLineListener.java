import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;

public class MyLineListener implements LineListener
{
	public static boolean playing = true;

	@Override
	public void update(LineEvent event)
	{
		LineEvent.Type type = event.getType();

		if (type == LineEvent.Type.START)
		{
			playing = true;
		}
		else if (type == LineEvent.Type.STOP)
		{
			playing = false;
		}
	}

	public boolean isPlaying()
	{
		return playing;
	}
}
